# 文件名：greeting_pipeline.py
# 作用：基于模板 + NLP 特征匹配的新春贺词生成（不使用 LLM）

import os
import numpy as np

from preprocess.parser import parse_pdf, parse_docx
from preprocess.cleaner import load_stopwords, clean_text

from feature.tfidf import TfidfFeature
from feature.doc2vec import Doc2VecFeature
from feature.sbert import SBERTFeature

from recommend.similarity import top_k_similarity
from generate.filler import fill_template

#新增LLM模块
from LLM.qwen_model import QWenGenerator

#**引用画像模块**
from profile.employee_profile import EmployeeProfileManager

class GreetingPipeline:
    """
    新春贺词生成系统（模板 + NLP 特征匹配 + **可选LLM**）
    """

    def __init__(self, feature_type="sbert",use_llm=False):
        self.feature_type = feature_type.lower()
        self.use_llm=use_llm
        self.employee_profile=EmployeeProfileManager()

        # 1️、加载停用词
        self.stopwords = load_stopwords("preprocess/stopwords.txt")

        # 2️、 加载模板
        self.templates = self._load_templates()

        # 3️、 初始化特征模型，并对模板向量化
        self.template_vectors = self._init_feature_model()
        """if not self.use_llm:
            self.template_vectors=self._init_feature_model()
        """
        #4、初始化LLM（可选）
        if self.use_llm:
            self.llm=QWenGenerator()
            template_name=None

    def _load_templates(self):
        """
        加载贺词模板（**name+content**    原：纯字符串列表）
        """
        template_dir = "data/templates"
        templates = []

        for file in os.listdir(template_dir):
            if file.endswith(".txt"):
                with open(os.path.join(template_dir, file), "r", encoding="utf-8") as f:
                    content = f.read().strip()
                    if content:
                        templates.append({
                            "name":file,        #模板文件名
                            "content":content   #模板内容
                        })


        return templates

    def _init_feature_model(self):
        """
        初始化特征模型，并对模板进行向量化
        """
        texts = [t["content"] for t in self.templates]

        if self.feature_type == "tfidf":
            self.feature_model = TfidfFeature()
            return self.feature_model.fit_transform(texts)

        elif self.feature_type == "doc2vec":
            self.feature_model = Doc2VecFeature()
            return self.feature_model.train(texts)

        elif self.feature_type == "sbert":
            self.feature_model = SBERTFeature()
            return self.feature_model.encode(texts)

        else:
            raise ValueError("不支持的特征类型")

    def _encode_report(self, text):
        """
        对员工年度总结进行向量化
        """
        if self.feature_type == "tfidf":
            return self.feature_model.transform([text])[0]

        elif self.feature_type == "doc2vec":
            return self.feature_model.infer_vector(text)

        elif self.feature_type == "sbert":
            return self.feature_model.encode([text])[0]

    def run_file(self, file_name, output_dir="data/generated_greetings"):
        """
        对单个年度总结文件生成新春贺词
        """
        file_path = os.path.join("data/reports", file_name)

        # 1、 文本解析
        if file_name.endswith(".pdf"):
            raw_text = parse_pdf(file_path)
        elif file_name.endswith(".docx"):
            raw_text = parse_docx(file_path)
        else:
            raise ValueError("仅支持 PDF / DOCX 文件")

        # 2️、 文本清洗
        cleaned_text = clean_text(raw_text, self.stopwords)

        # 3️、 员工信息（示例：从文件名推断）
        #原来：employee_name = os.path.splitext(file_name)[0]
        employee_name,name_source=self.employee_profile.get_employee_name(file_name)
        employee_info = {
            "姓名": employee_name,
            "年份": "2024",
            "关键词": "相关工作"
        }

       #模板匹配模式
        if not self.use_llm:
            report_vector = self._encode_report(cleaned_text)
            scores = top_k_similarity(report_vector, self.template_vectors, k=len(self.templates))
            best_idx = int(np.argmax(scores))
            best_template = self.templates[best_idx]
            template_name = best_template["name"]
            template_text = best_template["content"]

            # 模板填充
            greeting = fill_template(template_text, employee_info)

        # LLM 个性化润色模式
        else:
            # 先模板匹配生成基础贺词
            report_vector = self._encode_report(cleaned_text)
            scores = top_k_similarity(report_vector, self.template_vectors, k=len(self.templates))
            best_idx = int(np.argmax(scores))
            best_template = self.templates[best_idx]
            template_name = best_template["name"]
            template_text = best_template["content"]

            base_greeting = fill_template(template_text, employee_info)

            # 构造 prompt 给 QWen
            """prompt = (
                f"请根据以下员工年度总结和基础贺词，生成一段独特、个性化的新春贺词：\n\n"
                f"年度总结:\n{cleaned_text}\n\n"
                f"基础贺词:\n{base_greeting}\n\n"
                "要求：语言温暖、简洁，能够根据各个员工的年度总结生成足够个性化新春贺词，不要包含工号、日期或表格信息。\n\n贺词："
            )
            """

            prompt=f"""
            你是医院信息化部的一名员工，正在撰写对全院员工的中国新春贺词。
            【员工姓名】:{employee_name}
            【员工年度工作总结】:{cleaned_text}

            【写作要求】（必须严格遵守）：
            1、贺词开头 **必须以“{employee_name}同志：”作为第一行**
            2、贺词内容需结合年度总结中的工作表现与贡献
            3、语言正式、庄重、积极向上，符合机关单位风格
            4、字数控制在 80–120 字
            5、不得出现工号、表格字段、原文照抄内容
            6、只输出贺词正文，不要解释、不加标题、不加多余说明
            7、一定要是中国的跨年的新春祝福，贺词
            8、可以带有成语、古诗等有意境、有文化的语言
            9、不要写年份
            10、我所在的部门，也就是要发出贺词的部门是医院信息化部
            11、不要写医院成立多少年
            12、要根据员工的年度总结，以同事的角度，给员工发出新春贺词
            13、既要总结员工一年的成就，也要激励大家明年积极工作

            请开始生成贺词：
        """

            greeting = self.llm.generate_greeting(prompt)

        #**LLM输出后处理校验（强制包含员工姓名）**
        if employee_name not in greeting:
            greeting=f"{employee_name}同志：\n\n"+greeting

    
        # 4️⃣ 保存结果
        os.makedirs(output_dir, exist_ok=True)
        output_file = os.path.join(output_dir, f"{employee_name}_greeting.txt")
        with open(output_file, "w", encoding="utf-8") as f:
            f.write(greeting)

        print(f"✅ 贺词已生成并保存：{output_file}")
        print(f"👤 员工姓名解析结果: {employee_name}")
        print(f"📍 姓名来源: {'映射表 employee_map.json' if name_source=='map' else '文件名回退'}")


        return {
            "greeting": greeting,
            "feature_type": self.feature_type,
            "use_llm": self.use_llm,
            "employee_name": employee_name,
            "employee_name_source": name_source,
            "output_file": output_file
        }
