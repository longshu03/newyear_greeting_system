# 文件名：greeting_generator.py
# 作用：基于模板生成新春贺词（不使用 LLM）

from typing import Dict


class GreetingGenerator:
    """
    新春贺词生成器（模板填充版）
    """

    def __init__(self):
        """
        模板生成器不需要初始化模型
        """
        pass

    def generate(self, template: str, employee_info: Dict[str, str]) -> str:
        """
        根据模板和员工信息生成新春贺词

        :param template: 贺词模板字符串（包含占位符，如 {姓名}）
        :param employee_info: 员工信息字典
        :return: 生成的新春贺词
        """
        greeting = template

        # 使用员工信息填充模板
        for key, value in employee_info.items():
            placeholder = "{" + key + "}"
            greeting = greeting.replace(placeholder, value)

        return greeting
