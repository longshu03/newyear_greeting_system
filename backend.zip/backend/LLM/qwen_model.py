import os
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM

class QWenGenerator:
    """
    本地 QWen 模型封装模块
    功能：
    1. 自动下载到本地 HF_HOME
    2. 验证模型可用
    3. 提供 generate_greeting 接口生成文本
    """

    def __init__(self, model_name="Qwen/Qwen1.5-1.8B", hf_home="D:/Models"):
        # 设置本地缓存目录
        os.environ["HF_HOME"] = hf_home

        # 自动选择设备
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        print(f"📌 当前使用设备: {self.device}")

        # 下载并加载 tokenizer
        print("⬇️ 加载 tokenizer...")
        self.tokenizer = AutoTokenizer.from_pretrained(
            model_name,
            trust_remote_code=True,
            local_files_only=False  # 首次会下载到本地 HF_HOME
        )

        # 下载并加载模型
        print("⬇️ 加载模型...")
        self.model = AutoModelForCausalLM.from_pretrained(
            model_name,
            trust_remote_code=True,
            torch_dtype=torch.float16 if self.device=="cuda" else torch.float32,
            local_files_only=False
        )
        self.model.to(self.device)
        self.model.eval()
        print("✅ QWen 模型加载完成！")

    def generate_greeting(self, prompt, max_new_tokens=200, temperature=0.7, top_p=0.9):
        """
        基于输入 prompt 生成文本
        """
        inputs = self.tokenizer(prompt, return_tensors="pt").to(self.device)
        with torch.no_grad():
            outputs = self.model.generate(
                **inputs,
                max_new_tokens=max_new_tokens,
                do_sample=True,
                temperature=temperature,
                top_p=top_p
            )
        text = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
        # 只返回生成部分，去掉 prompt
        return text[len(prompt):].strip()
